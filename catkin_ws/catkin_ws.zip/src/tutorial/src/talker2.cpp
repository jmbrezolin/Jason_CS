#include "ros/ros.h"
#include "std_msgs/String.h"
#include <string>

std::stringstream ss1;
ros::Publisher chatter_pub;

void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
  //std_msgs::String msg;
  std::stringstream ss;
  ROS_INFO("I heard: [%s]", msg->data.c_str());
  ss1.clear();
  ss1 << msg->data.c_str();
  //msg.data = ss.str();
  chatter_pub.publish(msg);
}

int main(int argc, char **argv){
  ros::init(argc, argv, "talker2");
  ros::NodeHandle n;
  chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  ros::Subscriber sub = n.subscribe("chatter2", 1000, chatterCallback);
  std_msgs::String msg;
  //msg.data = ss1.str();
  //msg.data = sub.
  ROS_INFO("Also heard %s", msg.data.c_str());
  //ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter4", 1000);

  //chatter_pub.publish(msg);
  
  //ros::Rate loop_rate(1);
  //long long int count = 0;

  /*while(ros::ok()){
    std_msgs::String msg;
    std::stringstream ss;
    ss << "Hello World " << count;
    msg.data = ss.str();
   //msg.data = sub.data.c_str();
    ROS_INFO("%s", msg.data.c_str());
    chatter_pub.publish(msg);
    ros::spinOnce(); 
    loop_rate.sleep();
    ++count;
    } */

  ros::spin();
 
  return 0;
}

