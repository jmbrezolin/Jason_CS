#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "std_msgs/String.h"

using namespace cv;
using namespace std;

#include <sstream>

static const std::string OPENCV_WINDOW = "Image window";
 Mat src_gray;
 int thresh = 50;
 int max_thresh = 255;
 RNG rng(12345);

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
 
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;
  ros::Publisher chatter_pub;

  
public:
  ImageConverter()
    : it_(nh_)
  {
    // Subscrive to input video feed and publish output video feed
     
   

    image_sub_ = it_.subscribe("/camera/image/", 1, 
      &ImageConverter::imageCb, this,  image_transport::TransportHints("compressed"));
       

    image_pub_ = it_.advertise("/image_converter/output_video", 1);
    chatter_pub = nh_.advertise<std_msgs::String>("chatter2", 1000);

    cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(OPENCV_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
     Mat canny_output;
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;

    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    // Draw an example circle on the video stream
    if (cv_ptr->image.rows > 60 && cv_ptr->image.cols > 60)
      cv::circle(cv_ptr->image, cv::Point(50, 50), 10, CV_RGB(255,0,0));

    cvtColor( cv_ptr->image, src_gray, CV_BGR2GRAY );
    blur( src_gray, src_gray, Size(3,3) );
    //GaussianBlur( src_gray, src_gray, Size(3,3),0,0);

    /// Detect edges using canny
    //Canny( src_gray, canny_output, thresh, thresh*2, 3 );
    /// Find contours
   // findContours( canny_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

   /// Detect edges using Threshold
  threshold( src_gray, canny_output, thresh, 255, THRESH_BINARY );
  /// Find contours
  findContours( canny_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

     /// Get the moments
  vector<Moments> mu(contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { mu[i] = moments( contours[i], false ); }

  ///  Get the mass centers:
  vector<Point2f> mc( contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { mc[i] = Point2f( mu[i].m10/mu[i].m00 , mu[i].m01/mu[i].m00 ); }

 //MinrectSize
 /// Find the rotated rectangles and ellipses for each contour

  vector<RotatedRect> minRect( contours.size() );
  vector<RotatedRect> minEllipse( contours.size() );

  for( int i = 0; i < contours.size(); i++ )
     { minRect[i] = minAreaRect( Mat(contours[i]) );
       if( contours[i].size() > 5 )
         { minEllipse[i] = fitEllipse( Mat(contours[i]) ); }
     }

  //MinrectSize end

  /// Draw contours
  Mat drawing = Mat::zeros( canny_output.size(), CV_8UC3 );
  double area0;
  Mat ROI, HSV;
  cv::Mat image(cv_ptr->image);
  double hu[7];
  std::vector<cv::Point> approx;

  for( int i = 0; i< contours.size(); i++ )
     {
       Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
       area0 = contourArea(contours[i]);
       if (area0 > 10000.00 ){ 
       drawContours( drawing, contours, i, color, 2, 8, hierarchy, 0, Point() );
       //ROS_INFO(" * Contour[%d] - Area(0) = %f:", i,area0);
       
       
       //Moments
       
       cv::approxPolyDP(cv::Mat(contours[i]), approx, cv::arcLength(cv::Mat(contours[i]), true)*0.02, true);
       
       //ROS_INFO(" Contour[%d] -  Lados: %d  \n",i,approx.size());
               
       cv::Moments mom1 = cv::moments(contours[i]);
       cv::HuMoments(mom1, hu);
       //ROS_INFO(" * Contour_sem_approx[%d] - HuM(0) = %g, HuM(1) = %g, HuM(2) = %g, HuM(3) = %g, HuM(4) = %g, HuM(5) = %g, HuM(6) = %g \n", i, hu[0], hu[1],hu[2],hu[3],hu[4],hu[5],hu[6]);

       cv::Moments mom = cv::moments(approx); 
       cv::HuMoments(mom, hu);
       ROS_INFO(" * Contour_com_approx[%d] - HuM(0) = %g, HuM(1) = %g, HuM(2) = %g, HuM(3) = %g, HuM(4) = %g, HuM(5) = %g, HuM(6) = %g \n", i, hu[0], hu[1],hu[2],hu[3],hu[4],hu[5],hu[6]); 

        //Fim moments
       
       circle( drawing, mc[i], 4, color, -1, 8, 0 );
       Rect R=boundingRect(contours[i]); // Get bounding box for contour i
       //ROS_INFO(" * Contour[%d] - width(0) = %d:", i,R.width);
       //ROS_INFO(" * Contour[%d] - height(0) = %d:", i,R.height);
       
       //ROS_INFO(" * Contour[%d] - width(0) = %f:", i,minRect[i].size.width);
       //ROS_INFO(" * Contour[%d] - height(0) = %f:", i,minRect[i].size.height);

       ROI=image(R);
       cvtColor(ROI,HSV,CV_BGR2HSV);
       cv::Scalar mean = cv::mean(HSV);
       //ROS_INFO(" Contour[%d]: H: %.1f - S: %.1f - V: %.1f  \n", i, mean[0], mean[1], mean[2]);
       //ROS_INFO("Contour[%d] - Area OpenCV: %.2f", i, contourArea(contours[i]));
       //ROS_INFO("Contour[%d]:  MC-X: %f - MC-Y: %f \n", i, mc[i].x,mc[i].y);
       
       std_msgs::String msg1;

       std::stringstream ss;
       //ss << "Contour["<< i <<"]: Position:"<<mc[i].x<<","<<mc[i].y<<" Color(HSV):"<< mean[0]<<","<< mean[1]<<","<< mean[2];
       ss << "%g - %g - %g - %g - %g - %g - %g", hu[0], hu[1],hu[2],hu[3],hu[4],hu[5],hu[6];
       msg1.data = ss.str();
       //ROS_INFO("Entrei aqui");
       //ROS_INFO("%s", msg1.data.c_str());
       chatter_pub.publish(msg1);
       }
     }

    // Update GUI Window
    //cv::imshow(OPENCV_WINDOW, cv_ptr->image);
     //cv::imshow(OPENCV_WINDOW, drawing);
    //cv::waitKey(3);
    
    // Output modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
    
    //Teste
 
  }
};



int main(int argc, char** argv)
{
 

  ros::init(argc, argv, "image_converter");
  ImageConverter ic;
  ros::spin();
  return 0;
}
