#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "std_msgs/String.h"
#include <iostream>
#include <stdio.h>
#include <string>
#include <stdlib.h>
#include <fstream>


using namespace cv;
using namespace std;

#include <sstream>

static const std::string OPENCV_WINDOW = "Image window";
Mat src, src2, src3, color_src;
Mat src_gray, src_gray2, ROI,HSV;
string pos;
int thresh = 100;
int max_thresh = 255;
 RNG rng(12345);

/**
 * This tutorial demonstrates simple sending of messages over the ROS system.
 */
int main(int argc, char **argv)
{
  /**
   * The ros::init() function needs to see argc and argv so that it can perform
   * any ROS arguments and name remapping that were provided at the command line.
   * For programmatic remappings you can use a different version of init() which takes
   * remappings directly, but for most command-line programs, passing argc and argv is
   * the easiest way to do it.  The third argument to init() is the name of the node.
   *
   * You must call one of the versions of ros::init() before using any other
   * part of the ROS system.
   */
  
  //src2 = imread( argv[1], 1 );
  src2 = imread("ele_1.jpg", 1 );
  cv::Mat image(src2);
  //color_src = imread( argv[1], CV_LOAD_IMAGE_COLOR);
  color_src = imread( "ele_1.jpg", CV_LOAD_IMAGE_COLOR);

   //Filename

     time_t date_temp;       // Stores seconds elapsed since 01-01-1970
     struct tm *date_format; // Saves in Date format
     char date_out[25];      // Output string

     time(&date_temp);
     date_format = localtime(&date_temp);
     strftime(date_out, 25, "%Y%m%d_%H%M%S", date_format);

  //Filename
  
  int erosion_size = 1;  
       Mat element = getStructuringElement(cv::MORPH_CROSS,
              cv::Size(2 * erosion_size + 1, 2 * erosion_size + 1),
              cv::Point(erosion_size, erosion_size) );

  erode(src2, src, element);
  cvtColor( src, src_gray2, CV_BGR2GRAY );
  GaussianBlur( src_gray2, src_gray, Size(3,3), 0, 0 );

  Mat canny_output;
  vector<vector<Point> > contours;
  vector<Vec4i> hierarchy;

  adaptiveThreshold(src_gray, canny_output,255,ADAPTIVE_THRESH_GAUSSIAN_C, CV_THRESH_BINARY,15,-2);
  findContours( canny_output, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

  /// Get the moments
  vector<Moments> mu(contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { mu[i] = moments( contours[i], false ); }

  ///  Get the mass centers:
  vector<Point2f> mc( contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { mc[i] = Point2f( mu[i].m10/mu[i].m00 , mu[i].m01/mu[i].m00 ); }
  
  /// Find the convex hull object for each contour
   vector<vector<Point> >hull( contours.size() );
   for( int i = 0; i < contours.size(); i++ )
      {  convexHull( Mat(contours[i]), hull[i], false ); }

  /// Find the convex hull object for each contour
   vector<vector<Point> >hull2( contours.size() );
   for( int i = 0; i < contours.size(); i++ )
      {cv::approxPolyDP(cv::Mat(contours[i]), hull2[i], cv::arcLength(cv::Mat(contours[i]), true)*0.02, true);}

  double area0;
  std::vector<cv::Point> approx;
  double hu[7];
  double hu1[7];
  double aspect_ratio,hull_area,solidity,extent;
  double h,w;

  cv::Size s = image.size();
   int rows = s.height;
   int cols = s.width;
   float img_y=rows/2;
   float img_x=cols/2;

  ros::init(argc, argv, "talker");

  /**
   * NodeHandle is the main access point to communications with the ROS system.
   * The first NodeHandle constructed will fully initialize this node, and the last
   * NodeHandle destructed will close down the node.
   */
  ros::NodeHandle n;

  /**
   * The advertise() function is how you tell ROS that you want to
   * publish on a given topic name. This invokes a call to the ROS
   * master node, which keeps a registry of who is publishing and who
   * is subscribing. After this advertise() call is made, the master
   * node will notify anyone who is trying to subscribe to this topic name,
   * and they will in turn negotiate a peer-to-peer connection with this
   * node.  advertise() returns a Publisher object which allows you to
   * publish messages on that topic through a call to publish().  Once
   * all copies of the returned Publisher object are destroyed, the topic
   * will be automatically unadvertised.
   *
   * The second parameter to advertise() is the size of the message queue
   * used for publishing messages.  If messages are published more quickly
   * than we can send them, the number here specifies how many messages to
   * buffer up before throwing some away.
   */
  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter5", 1000);

  ros::Rate loop_rate(10);

  /**
   * A count of how many messages we have sent. This is used to create
   * a unique string for each message.
   */
  int count = 0;
  
  while (ros::ok())
  {
    // std_msgs::String msg1;
   //  std::stringstream ss1;

   // ss1 <<pos<<"Inicio";
   // msg1.data = ss1.str();

   // ROS_INFO("%s", msg1.data.c_str());

    //chatter_pub.publish(msg1);
    
      
     std::ofstream outfile; 
     outfile.open("afile.dat", std::ofstream::out | std::ofstream::app);

     for( int i = 0; i< contours.size(); i++ )
     {
      
       area0 = contourArea(contours[i]);
       hull_area =  contourArea(hull[i]);
        
     // if (area0 > 10000.00 && area0 < 22000.00){
     if (area0 > 2700.00 && area0 < 21000.00){

       Rect R=boundingRect(contours[i]);
       ROI=color_src(R);
       cvtColor(ROI,HSV,CV_BGR2HSV);
       //cvtColor(HSV,ROI,CV_BGR2HSV);
       cv::Scalar mean = cv::mean(ROI);
        //printf(" * Contour[%d] - Colors R: %.0f -G:%.0f  - B: %.0f  \n", i, mean[0],mean[1], mean[2]); 
        w=R.width;
        h=R.height;
        aspect_ratio = w/h;
        solidity =  area0/hull_area;
        extent  = area0 / (R.width * R.height);
       //printf(" * Contour[%d] - Witdh: %d \n",i,R.width); 
       //printf(" * Contour[%d] - Height: %d \n",i,R.height); 
       //printf(" * Contour[%d] - Aspect Ratio: %g \n",i,aspect_ratio); 
       //printf(" * Contour[%d] - Solidity: %f \n",i,solidity);
       //printf(" * Contour[%d] - Extent: %f \n",i,extent); 

       cv::approxPolyDP(cv::Mat(contours[i]), approx, cv::arcLength(cv::Mat(contours[i]), true)*0.02, true); 
       
       //printf(" * Contour[%d] - Size: %d - Area (M_00) = %.2f - Centroide(x,y): %.0f , %.0f \n", i, hull[i].size(), mu[i].m00, mc[i].x, mc[i].y);
       cv::Moments mom = cv::moments(hull[i]); 
       cv::HuMoments(mom, hu);
       //printf(" %.0f %.0f %.0f  \n", mean[0],mean[1], mean[2]);  
       //printf(" %g %g %g %g %g %g %g \n", hu[0], hu[1],hu[2],hu[3],hu[4],hu[5],hu[6]);
       cv::approxPolyDP(cv::Mat(contours[i]), approx, cv::arcLength(cv::Mat(contours[i]), true)*0.02, true); 
       cv::Moments mom1 = cv::moments(approx); 
       cv::HuMoments(mom1, hu1);
       //printf(" * Contour [%d]  Hu-Moments - HuM(1) = %g, HuM(2) = %g, HuM(3) = %g \n", i, hu[0], hu[1],hu[2]);
       //printf(" * Contour [%d]  Hu-Moments - HuM(4) = %g, HuM(5) = %g,  \n", i, hu[3],hu[4]);
       //printf(" * Contour [%d]  Hu-Moments - HuM(6) = %g, HuM(7) = %g \n", i, hu[5],hu[6]);
       
       if (mc[i].x > img_x){
          pos="Direita"; }

       if (mc[i].x < img_x){
          pos="Esquerda"; }
       

      

  
    std_msgs::String msg;
    std::stringstream ss;
    
    ss <<date_out<<"teste"<<i<<","<< mean[0]<<","<<mean[1]<<","<<mean[2]<<","<<hu[0]<<","<<hu[1]<<","<<hu[2]<<","<<hu[3]<<","<<hu[4]<<","<<hu[5]<<","<<hu[6]<<","<<mc[i].x<<","<<mc[i].y;
    msg.data = ss.str();
    outfile << msg.data.c_str() << endl;
    
    ROS_INFO("%s", msg.data.c_str());

    chatter_pub.publish(msg);
   
    }
      
   }
   outfile.close();
    ros::spinOnce();

    loop_rate.sleep();
    ++count;
  }


  return 0;
}
